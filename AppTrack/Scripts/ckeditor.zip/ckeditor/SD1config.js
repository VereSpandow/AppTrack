
CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
    config.uiColor = '#CCDDEE',
    config.contentsCss = ['/Content/bootstrap.css', '/Content/loyaltybenefits.css'];
    config.toolbarCanCollapse = true;
};
